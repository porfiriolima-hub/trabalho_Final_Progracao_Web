<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link active" href="../">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Quem Somos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Clientes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Produtos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Serviços</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Fale Conosco</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Sistema</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="../JOASLUNAs-login">Login</a>
      </li>
    </ul>
  </div>
</nav>